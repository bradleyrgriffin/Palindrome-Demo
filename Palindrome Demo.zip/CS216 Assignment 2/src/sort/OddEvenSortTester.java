/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sort;

/**
 *
 * @author jgrady
 */
public class OddEvenSortTester 
{
    
   public static void main(String[] args)
      {
          // TO-DO: Your code goes here
          Array a = new Array(10);
          a.insert(1);
          a.insert(3);
          a.insert(5);
          a.insert(2);
          a.insert(4);
          a.insert(6);
          a.insert(8);
          a.insert(7);
          a.insert(10);
          a.insert(9);
          a.display();
          a.oddEvenSort();
          a.display();
         
      }  
   
}
