package palindrome;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Tests if a String is a palindrome; uses a queue data structure to process the
 * characters in the String.
 */
public class PalindromeTester {

    public static void main(String[] args) throws IOException {
        //Create and read input in.
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        
        //Remove spaces, and punctuation from the input. Also converting to
        //Lower case so all ASCII values are the same ranges.
        s = s.replaceAll("\\W","").toLowerCase();
        
        //Creating new queue, then populating it.
        Queue myQueue = new Queue(s.length());
        for(int i = s.length() - 1; i >= 0; i--){
            myQueue.insert(((int)s.charAt(i)));
        }
        
        //Establishing flag.
        boolean flag = true;
        
        //Establishing inside counter for the input-string.
        int i = 0;
        
        //Creating the while loop that ensures if the input is a palindrome or
        //not, returning the value to the flag boolean. Breaking outof the loop
        //if the input is not a palindrome.
        while (!myQueue.isEmpty()){
            if(myQueue.peekFront() == s.charAt(i)){  //Comparison
            } else{
                flag = false;
                break;
            }
            myQueue.remove();
            i+=1;
        }
        
        //If "flag" is true, it is a palindrome, and will print the response,
        //Otherwise, it is not a palindrome.
        if(flag){
            System.out.println("The phrase is a palindrome.");
        }else{
            System.out.println("The phrase is not a palindrome.");
        }
    }
}
