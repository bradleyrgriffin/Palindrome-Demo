package palindrome;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Tests if a String is a palindrome; uses a queue data structure to process the
 * characters in the String.
 */
public class PalindromeTester {

    public static void main(String[] args) throws IOException {
        //Create and read input in.
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        
        //Remove spaces, and punctuation from the input. Also converting to
        //Lower case so all ASCII values are the same ranges.
        s = s.replaceAll("\\W","").toLowerCase();
        
        Queue myQueue = new Queue(s.length());
        for(int i = 0; i < s.length()/2; i++){
            char c = s.charAt(i);
            if (c >= 97 && c <=122){
                myQueue.insert(c);
            }
        }
        
        int checkIndex = s.length() -1;
        boolean flag = true;
        while(!myQueue.isEmpty() && flag){
            char stringChar = s.charAt(checkIndex);
            if (stringChar >= 97 && stringChar <= 122){
                char queueChar = (char)myQueue.remove();
                if (queueChar != stringChar){
                    flag = false;
                }
                checkIndex--;
            }
        }      
        //If "flag" is true, it is a palindrome, and will print the response,
        //Otherwise, it is not a palindrome.
        if(flag){
            System.out.println("The phrase is a palindrome.");
        }else{
            System.out.println("The phrase is not a palindrome.");
        }
    }
}
